package DAOs;
import Entidades.Formulariodw;
import java.util.ArrayList;
import java.util.List;

public class DAOFormulariodw extends DAOGenerico<Formulariodw> {

    public DAOFormulariodw() {
        super(Formulariodw.class);
    }

    public int autoIdFormulariodw() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idFormulariodw) FROM Formulariodw e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Formulariodw> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Formulariodw e WHERE e.email LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Formulariodw> listById(int id) {
        return em.createQuery("SELECT e FROM Formulariodw e WHERE e.idFormulariodw = :id").setParameter("id", id).getResultList();
    }

    public List<Formulariodw> listInOrderNome() {
        return em.createQuery("SELECT e FROM Formulariodw e ORDER BY e.nome").getResultList();
    }

    public List<Formulariodw> listInOrderId() {
        return em.createQuery("SELECT e FROM Formulariodw e ORDER BY e.idFormulariodw").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Formulariodw> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getEmail()
 + "-" + lf.get(i).getNome()
 + "-" + lf.get(i).getIdade()
 + "-" + lf.get(i).getTelefone()
 + "-" + lf.get(i).getVaga()
 + "-" + lf.get(i).getNivel()
 + "-" + lf.get(i).getCurso()
 + "-" + lf.get(i).getDescricao()
);
        }
        return ls;
    }
}
