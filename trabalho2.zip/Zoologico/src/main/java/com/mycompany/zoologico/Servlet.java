/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.zoologico;

import DAOs.DAOFormulariodw;
import Entidades.Formulariodw;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Isadora M.M
 */
@WebServlet(name = "Servlet", urlPatterns = {"/Servlet"})
public class Servlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String Email = request.getParameter("e-mail");
            String Nome = request.getParameter("login");
            String Idade = request.getParameter("idade");
            String Telefone = request.getParameter("telefone");
            String Vaga = request.getParameter("vaga");
            String Nivel = request.getParameter("escolaridade");
            String Curso = request.getParameter("curso");
            String Descricao = request.getParameter("descricao");
            List<Formulariodw> dados = savePrint(Email, Nome, Idade, Telefone, Vaga, Nivel, Curso, Descricao);
            String aux[];
            aux = String.valueOf(dados).split(";");

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Servlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Email: " + aux[0].substring(1) + "</h1>");
            out.println("<h1>Nome: " + aux[1] + "</h1>");
            out.println("<h1>Idade: " + aux[2] + "</h1>");
            out.println("<h1>Telefone: " + aux[3] + "</h1>");
            out.println("<h1>Vaga: " + aux[4] + "</h1>");
            out.println("<h1>Nivel: " + aux[5] + "</h1>");
            out.println("<h1>Curso: " + aux[6] + "</h1>");
            out.println("<h1>Descrição: " + aux[7].substring(0, aux[7].length() - 1) + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    private List<Formulariodw> savePrint(String Email, String Nome, String Idade, String Telefone, String Vaga, String Nivel, String Curso, String Descricao) {
        DAOFormulariodw controle = new DAOFormulariodw();
        Formulariodw entidade = new Formulariodw();

        entidade.setEmail(Email);
        entidade.setNome(Nome);
        entidade.setIdade(Integer.valueOf(Idade));
        entidade.setTelefone(Telefone);
        entidade.setVaga(Vaga);
        entidade.setNivel(Nivel);
        entidade.setCurso(Curso);
        entidade.setDescricao(Descricao);

        controle.inserir(entidade);

        List<Formulariodw> dados = new ArrayList<>();
        dados = controle.listByNome(Email);
        return dados;
    }
}
